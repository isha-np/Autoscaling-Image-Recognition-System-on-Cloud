

REQUEST_QUEUE_NAME = 'requests_sss.fifo'
RESPONSE_QUEUE_NAME = 'response_sss.fifo'

CTR_MAX = 19

BUCKET_NAME_INPUT = 'ccp1ip'
BUCKET_NAME_OUTPUT = 'ccp1op'

APP_TIER_PREFIX = 'sss_app_tier_'

MIN_APP_TIERS = 0
MAX_APP_TIERS = 19


S3_OUTPUT_FOLDER = 'OUTPUT/'
S3_INPUT_FOLDER = 'INPUT/'
